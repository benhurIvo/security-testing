import net.sourceforge.jwebunit.junit.WebTester;
import net.sourceforge.jwebunit.util.TestingEngineRegistry;
import org.junit.Before;
import org.junit.Test;


public class Trial {

	private WebTester tester;
	
	@Before
	public void prepare(){
		tester = new WebTester();
		tester.setTestingEngineKey(TestingEngineRegistry.TESTING_ENGINE_HTMLUNIT);
		tester.getTestContext().setBaseUrl("http://localhost/schoolmate");
	}
	@Test
	public void test(){
		
		tester.beginAt("/index.php");
		tester. setTextField("username", "test");
		tester. setTextField("password", "test");
		tester.submit();
		tester.assertTitleEquals("SchoolMate - School Name");
	}
}
