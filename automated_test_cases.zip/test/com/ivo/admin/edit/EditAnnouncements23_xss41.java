/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ivo.admin.edit;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;
import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import org.junit.*;
import net.sourceforge.jwebunit.junit.*;
import org.xml.sax.helpers.AttributesImpl;
/**
 *
 * @author benhur
 */
public class EditAnnouncements23_xss41 {
    private WebTester tester;
	
	
	@Before
	public void prepare(){
		tester = new WebTester ();
		tester.setBaseUrl("http://localhost/schoolmate");
		tester.beginAt("/index.php");
		tester.setTextField("username", "test");
		tester.setTextField("password", "test");
		tester.submit();
		tester.assertMatch("Manage Classes");
		tester.clickLinkWithExactText("Announcements");
		tester.assertMatch("Manage Announcements");
		}
	
	@Test
	public void page(){
		tester.setWorkingForm("announcements");
		tester.setTextField("page", "1' ><a href=\"a.it\"> malicious </a><br '");
		tester.checkCheckbox("delete[]","1");
		 tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit Announcement");
		tester.assertLinkNotPresentWithText("malicious");	
	}
	
	@Test
	public void page2(){
		tester.setWorkingForm("announcements");
		tester.setTextField("page2", "19' ><a href=\"a.it\"> malicious </a><br '");
		addSubmitButton("//form[@name='announcements']");	
		tester.checkCheckbox("delete[]","1");
		tester.submit();
		tester.assertMatch("Edit Announcement");
		tester.assertLinkNotPresentWithText("malicious");	
	}
	
	@Test
	public void id(){
		tester.setWorkingForm("announcements");
		tester.getElementByXPath("//input[@type='checkbox' and @value='1']").setAttribute("value", "1 -- '><a href=\"a.it\"> malicious </a><br ");
		tester.checkCheckbox("delete[]");
		tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit Announcement");
	    tester.assertLinkNotPresentWithText("malicious");
	}
			
	private void addSubmitButton(String fromXpath){
		IElement element = tester.getElementByXPath(fromXpath);
		DomElement form = ((HtmlUnitElementImpl)element).getHtmlElement();
		InputElementFactory factory = InputElementFactory.instance;
		AttributesImpl attributes = new AttributesImpl();
		attributes.addAttribute("", "", "type", "", "submit");
		HtmlElement submit = factory.createElement(form.getPage(), "input", attributes);
		form.appendChild(submit);
		
	}

}
