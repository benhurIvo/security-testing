/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ivo.admin.edit;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;
import com.ivo.general.Gen;
import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import org.junit.*;
import net.sourceforge.jwebunit.junit.*;
import org.xml.sax.helpers.AttributesImpl;
/**
 *
 * @author benhur
 */
public class EditUser68_xss149 {
    private WebTester tester;
	
	
	@Before
	public void prepare(){
		tester = new WebTester ();
		tester.setBaseUrl("http://localhost/schoolmate");
		tester.beginAt("/index.php");
		tester.setTextField("username", "test");
		tester.setTextField("password", "test");
		tester.submit();
		tester.assertMatch("Manage Classes");
		tester.clickLinkWithExactText("Users");
		tester.assertMatch("Manage Users");
		}
	
	@Test
	public void page(){
		tester.setWorkingForm("users");
		tester.setTextField("page", "1' ><a href=\"a.it\"> malicious </a><br '");
		tester.checkCheckbox("delete[]","1");
		 tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit User");
		tester.assertLinkNotPresentWithText("malicious");	
	}
	
	@Test
	public void page2(){
		tester.setWorkingForm("users");
		tester.setTextField("page2", "15' ><a href=\"a.it\"> malicious </a><br '");
		Gen.addSubmitButton(tester,"//form[@name='users']");	
		tester.checkCheckbox("delete[]","1");
		tester.submit();
		tester.assertMatch("Edit User");
		tester.assertLinkNotPresentWithText("malicious");	
	}
	
	@Test
	public void id(){
		tester.setWorkingForm("users");
		tester.getElementByXPath("//input[@type='checkbox' and @value='1']").setAttribute("value", "1 -- '><a href=\"a.it\"> malicious </a><br ");
		tester.checkCheckbox("delete[]");
		tester.clickButtonWithText("Edit");
		tester.assertMatch("Edit User");
	    tester.assertLinkNotPresentWithText("malicious");
	}

}
