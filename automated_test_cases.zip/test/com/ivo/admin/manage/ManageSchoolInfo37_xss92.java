/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ivo.admin.manage;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;
import com.ivo.general.Gen;
import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import org.junit.*;
import net.sourceforge.jwebunit.junit.*;
import org.xml.sax.helpers.AttributesImpl;
/**
 *
 * @author benhur
 */
public class ManageSchoolInfo37_xss92 {
    WebTester tester;
	private String previousvalue1;
	private String previousvalue2;


	@Before
	public void prepare(){
		tester = new WebTester();
		tester.setBaseUrl("http://localhost/schoolmate");
		tester.beginAt("/index.php");
		tester.setTextField("username", "test");
		tester.setTextField("password", "test");
		tester.submit();	
		tester.assertTitleEquals("SchoolMate - School Name");
		tester.assertMatch("Manage Classes");
		tester.setWorkingForm("admin");		
	}
@Test
public void page2(){
	tester.setTextField("page2", "1 '> <a href =\"a.it\">malicious</a><br '");
	Gen.addSubmitButton(tester,"//form[@name='admin']");
	tester.submit();
	tester.assertMatch("Manage School Information");
        tester.assertLinkNotPresentWithText("malicious");
}
@Test
public void page(){
	tester.setTextField("page", "1 '> <a href =\"a.it\">malicious</a><br '");
	tester.clickLinkWithText("School");
	tester.assertMatch("Manage School Information");
        tester.assertLinkNotPresentWithText("malicious");
}
@Test
public void sitetext(){
	tester.clickLinkWithText("School");
	tester.assertMatch("Manage School Information");
	previousvalue1= tester.getElementByXPath("html//textarea[@name='sitetext']").getTextContent();
        tester.setWorkingForm("info");
        tester.setTextField("sitetext", "Original Massage </textarea><a href=\\'a.it\\'>malicious</a>");
	tester.clickButtonWithText(" Update ");
	tester.clickLinkWithText("Log Out");
	tester.assertMatch("Today's Message");
	tester.assertLinkNotPresentWithText("malicious");
}
@Test
public void sitemessage(){
	tester.clickLinkWithText("School");
	tester.assertMatch("Manage School Information");
	previousvalue2= tester.getElementByXPath("html//textarea[@name='sitemessage']").getTextContent();
    tester.setWorkingForm("info");
	tester.setTextField("sitemessage", "Original Massage </textarea><a href=\\'a.it\\'>malicious</a>");
	tester.clickButtonWithText(" Update ");
	tester.clickLinkWithText("Log Out");
	tester.assertMatch("Today's Message");
	tester.assertLinkNotPresentWithText("malicious");
}

@After
public void cleanUpText(){
	if(previousvalue1!=null){
	tester.beginAt("/index.php");
	tester.setTextField("username", "test");
	tester.setTextField("password", "test");
	tester.submit();	
	tester.assertTitleEquals("SchoolMate - School Name");
	tester.clickLinkWithText("School");
	tester.assertMatch("Manage School Information");
	tester.setTextField("sitetext", previousvalue1);
	tester.clickButtonWithText(" Update ");	
}
}
@After
public void cleanUpMessage(){
	if(previousvalue2!=null){
	tester.beginAt("/index.php");
	tester.setTextField("username", "test");
	tester.setTextField("password", "test");
	tester.submit();	
	tester.assertTitleEquals("SchoolMate - School Name");
	tester.clickLinkWithText("School");
	tester.assertMatch("Manage School Information");
	tester.setTextField("sitemessage", previousvalue2);
	tester.clickButtonWithText(" Update ");	
}
}
}
