/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ivo.admin.manage;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;
import com.ivo.general.Gen;
import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import org.junit.*;
import net.sourceforge.jwebunit.junit.*;
import org.xml.sax.helpers.AttributesImpl;
/**
 *
 * @author benhur
 */
public class ManageStudents211_xss293 {
    private WebTester tester;
	
	
	@Before
	public void prepare(){
		tester = new WebTester ();
		tester.setBaseUrl("http://localhost/schoolmate");
		tester.beginAt("/index.php");
		tester.setTextField("username", "test");
		tester.setTextField("password", "test");
		tester.submit();
		tester.assertMatch("Manage Classes");
		}
	
	@Test
	public void page(){
		tester.setWorkingForm("admin");
		tester.setTextField("page", "1' ><a href=\"a.it\"> malicious </a><br '");
		tester.clickLinkWithExactText("Students");
		tester.assertMatch("Manage Students");
		tester.assertLinkNotPresentWithText("malicious");	
	}
	
	@Test
	public void page2(){
		tester.setWorkingForm("admin");
		tester.setTextField("page2", "2' ><a href=\"a.it\"> malicious </a><br '");
		Gen.addSubmitButton(tester,"//form[@name='admin']");	
		tester.submit();
		tester.assertMatch("Manage Students");
		tester.assertLinkNotPresentWithText("malicious");	
	}
	
	@Test
	public void onpage() {
		tester.clickLinkWithExactText("Students");
		tester.assertMatch("Manage Students");
		tester.setTextField("onpage", "1' ><a href=\"a.it\"> malicious </a><br '");
		tester.setWorkingForm("students");
		Gen.addSubmitButton(tester,"//form[@name='students']");	
		tester.submit();
		tester.assertMatch("Manage Students");
		tester.assertLinkNotPresentWithText("malicious");
	}

}
