/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ivo.general;

import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;
import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import net.sourceforge.jwebunit.junit.WebTester;
import org.xml.sax.helpers.AttributesImpl;

/**
 *
 * @author benhur
 */
public class Gen {
    
    public static void addSubmitButton(WebTester tester,String fromXpath) {
	IElement element = tester.getElementByXPath(fromXpath);
	DomElement form = ((HtmlUnitElementImpl)element).getHtmlElement();
	InputElementFactory factory = InputElementFactory.instance;
	AttributesImpl attributes = new AttributesImpl();
	attributes.addAttribute("", "", "type", "", "submit");
	HtmlElement submit = factory.createElement(form.getPage(), "input", attributes);
	form.appendChild(submit);
}
}
