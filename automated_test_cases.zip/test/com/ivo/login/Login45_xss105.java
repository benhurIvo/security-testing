/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ivo.login;
import org.junit.*;
import net.sourceforge.jwebunit.junit.*;
/**
 *
 * @author benhur
 */
public class Login45_xss105 {
private WebTester tester;
	private String previousValue;
	
	@Before
	public void prepare(){
		tester = new WebTester ();
		tester.setBaseUrl("http://localhost/schoolmate");
		tester.beginAt("/index.php");
		tester.setTextField("username", "test");
		tester.setTextField("password", "test");
		tester.submit();
		tester.assertTitleEquals("SchoolMate - School Name");
		tester.clickLinkWithText("School");
		tester.assertTextPresent("Manage School Information");
		tester.assertMatch("Manage School Information");
	}
	
	@Test
	public void message(){
		previousValue = tester.getElementByXPath("html//textarea [@name = 'sitemessage']").getTextContent();
		tester.setTextField("sitemessage", "This is the Message of the day </textarea><a href=\\'a.it\\'>malicious</a>");
		tester.clickButtonWithText(" Update ");
		tester.clickLinkWithText("Log Out");
		tester.assertTextPresent("Today's Message");
		tester.assertLinkNotPresentWithText("malicious"); //Test should not pass coz the malicious link was found 
	}
	
	
	@After
	public void cleanUp(){
		if (previousValue!=null){
			tester.beginAt("/index.php");
			tester.setTextField("username", "test");
			tester.setTextField("password", "test");
			tester.submit();
			tester.assertTitleEquals("SchoolMate - School Name");
			tester.clickLinkWithText("School");
			tester.assertTextPresent("Manage School Information");
			tester.assertMatch("Manage School Information");
			tester.setTextField("sitemessage", previousValue);
			tester.clickButtonWithText(" Update ");	
		}
	}
	
	
}


