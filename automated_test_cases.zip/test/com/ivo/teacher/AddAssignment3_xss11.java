/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ivo.teacher;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;
import com.ivo.general.Gen;
import net.sourceforge.jwebunit.api.IElement;
import net.sourceforge.jwebunit.htmlunit.HtmlUnitElementImpl;
import org.junit.*;
import net.sourceforge.jwebunit.junit.*;
import org.xml.sax.helpers.AttributesImpl;
/**
 *
 * @author benhur
 */
public class AddAssignment3_xss11 {
    private WebTester tester;

@Before
	public void prepare(){
		tester = new WebTester ();
		tester.setBaseUrl("http://localhost/schoolmate");
		tester.beginAt("/index.php");
		tester.setTextField("username", "teacher");
		tester.setTextField("password", "teacher");
		tester.submit();
		tester.assertMatch("benh ivo's Classes");
		tester.clickLinkWithText("PE");
		tester.assertTextPresent("Class Settings");
		tester.clickLinkWithText("Assignments");
		tester.assertMatch("Manage Assignments");
		tester.setWorkingForm("assignments");
	}
	@Test
	public void page(){
		tester.setTextField("page", "2 ' ><a href=\"a.it\"> malicious </a><br '");
		tester.clickButtonWithText("Add");
		tester.assertMatch("Add New Assignment");
		tester.assertLinkNotPresentWithText("malicious");
	}
	
	@Test
	public void page2(){
		tester.setTextField("page2", "4 ' ><a href=\"a.it\"> malicious </a><br '");
		Gen.addSubmitButton(tester,"//form[@name='assignments']");		
		tester.submit();	
		tester.assertMatch("Add New Assignment");
		tester.assertLinkNotPresentWithText("malicious");
	}
	
	@Test
	public void selectclass(){
		tester.setTextField("selectclass", "2 ' ><a href=\"a.it\"> malicious </a><br '");
		tester.clickButtonWithText("Add");
		tester.assertMatch("Add New Assignment");
		tester.assertLinkNotPresentWithText("malicious");
	}

}
